
@extends('admin.master')

@section('body')

    <div class="container-fluid">
        <div class="row">
            <div class="offset-1 col-lg-10">
                <div class="card">
                    <div class="card-body">
                        @if(Session::get('message'))
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <h4 class="text-center text-success">{{Session::get('message')}}</h4>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times</span>
                                </button>
                            </div>
                            else
                        @endif
                        <h4 class="card-title">Edit Product</h4>
                        {{Form::open(['route'=>'update-product','method'=>'post','class'=>'form-horizontal','enctype' =>'multipart/form-data','name'=> 'editProductForm'])}}
                        <div class="form-group row">
                            <label class="control-form-label col-md-3">Product Name</label>
                            <div class="col-md-9">
                                <select class="form-control" name="category_id">
                                    <option>---Select Category Name---</option>
                                    @foreach($categories as $category)
                                        <option value="{{$category->id}}">{{$category->Category_name}}</option>

                                    @endforeach
                                </select>

                                {{--validation start--}}
                                <span class="text-danger">{{$errors->has('category_id') ? $errors->first('category_id') : ''}}</span>
                                {{--validation end--}}



                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-form-label col-md-3">Brand Name</label>
                            <div class="col-md-9">
                                <select class="form-control" name="brand_id">
                                    <option>---Select Brand Name---</option>
                                    @foreach($brands as $brand)
                                        <option value="{{$brand->id}}">{{$brand->brand_name}}</option>

                                    @endforeach
                                </select>
                                {{--validation start--}}
                                <span class="text-danger">{{$errors->has('$brand_id') ? $errors->first('$brand_id') : ''}}</span>
                                {{--validation end--}}

                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-form-label col-md-3">Product Name</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="product_name" value="{{$product->product_name}}">
                                <input type="hidden" class="form-control" name="id" value="{{$product->id}}">
                                {{--validation start--}}
                                <span class="text-danger">{{$errors->has('product_name') ? $errors->first('product_name') : ''}}</span>
                                {{--validation end--}}
                            </div>

                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3">Product Price</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="product_price" value="{{$product->product_price}}">
                                {{--validation start--}}
                                <span class="text-danger">{{$errors->has('product_price') ? $errors->first('product_price') : ''}}</span>
                                {{--validation end--}}
                            </div>

                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3">Product Quantity</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="product_quantity" value="{{$product->product_quantity}}">
                                {{--validation start--}}
                                <span class="text-danger">{{$errors->has('product_quantity') ? $errors->first('product_quantity') : ''}}</span>
                                {{--validation end--}}
                            </div>

                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3">Product Short Description</label>
                            <div class="col-md-9">
                                <textarea class="form-control" name="short_desc" rows="2">{{$product->short_desc}}</textarea>
                                {{--validation start--}}
                                <span class="text-danger">{{$errors->has('short_desc') ? $errors->first('short_desc') : ''}}</span>
                                {{--validation end--}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3">Product Long Description</label>
                            <div class="col-md-9">
                                <textarea class="form-control" id="summary-ckeditor" name="long_desc" rows="5">{{$product->long_desc}}</textarea>
                                {{--validation start--}}
                                <span class="text-danger">{{$errors->has('long_desc') ? $errors->first('long_desc') : ''}}</span>
                                {{--validation end--}}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-form-label col-md-3">Product Image
                            </label>
                            <div class="col-md-9">
                                <input type="file"  name="product_image" multiple><br>
                                {{--validation start--}}
                                <span class="text-danger">{{$errors->has('product_image') ? $errors->first('product_image') : ''}}</span>
                                <img src="{{asset($product->product_image)}}">
                                {{--validation end--}}
                            </div>
                        </div>


                        <div class="form-group row">
                            <label class="col-sm-3 ">Publication Status</label>
                            <div class="col-sm-7 radio">
                                <input type="radio" name="publication_status" value="1" {{$product->publication_status == 1? 'checked':''}}>Published
                                <input type="radio" name="publication_status" value="0" {{$product->publication_status == 0? 'checked':''}}>Unpublished
                                <br>
                                <span class="text-danger">{{$errors->has('publication_status') ? $errors->first('publication_status') : ''}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="border-top">
                        <div class="card-body">
                            <button type="submit"  name="btn" class="btn btn-primary">Submit</button>
                        </div>
                    </div>






                    {{Form::close()}}


                </div>
            </div>
        </div>
    </div>
    </div>

   <script>
       document.forms['editProductForm'].elements['category_id'].value= '{{$product->category_id}}';
       document.forms['editProductForm'].elements['brand_id'].value= '{{$product->brand_id}}';
   </script>


@endsection