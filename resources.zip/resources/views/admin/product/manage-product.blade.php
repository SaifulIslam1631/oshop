@extends('admin.master')

@section('body')

    <div class="card">
        <div class="card-body">
            @if(Session::get('message'))
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <h4 class="text-center text-success">{{Session::get('message')}}</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                else
            @endif


            <h5 class="card-title">Basic Datatable</h5>
            <div class="table-responsive">
                <table id="zero_config" class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>SI NO.</th>
                        <th>Category Name</th>
                        <th>Brand Name</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Product Quantity</th>

                        <th>Product Image </th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    @php($i=1)
                    @foreach($products as $product)
                    <tbody>
                    <tr>
                        <th>{{$i++}}</th>
                        <th>{{$product->category_name}}</th>
                        <th>{{$product->brand_name}}</th>
                        <th>{{$product->product_name}}</th>
                        <th>{{$product->product_price}}</th>
                        <th>{{$product->product_quantity}}</th>
                        <th>{{$product->short_desc}}</th>
                        <th>{{$product->long_desc}}</th>
                        <th>
                            <img src="{{asset($product->product_image)}}">
                        </th>
                        <th>{{$product->publication_status == 1?'Published' : 'Unpublished'}}</th>
                        <th>
                            @if($product->publication_status == 1)
                                <a href="" class="btn btn-primary">
                                    <span><i class="fa fa-arrow-up"></i></span>
                                </a>
                            @else
                                <a href="" class="btn btn-warning">
                                    <span><i class="fa fa-arrow-down"></i></span>
                                </a>
                            @endif
                            <a href="{{route('edit-product',['id' => $product->id])}}" class="btn btn-success" >
                                <span><i class="fa fa-edit"></i></span>
                            </a>

                            <a href="{{route('delete-product',['id' => $product->id])}}" class="btn btn-danger">
                                <span><i class="fa fa-trash"></i></span>
                            </a>
                        </th>
                    </tr>
                    </tbody>
                    @endforeach

                    <tfoot>
                    <tr>
                        <th>SI NO.</th>
                        <th>Category Name</th>
                        <th>Brand Name</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Product Quantity</th>
                        <th>Product Image </th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                    </tfoot>
                </table>
            </div>

        </div>
    </div>


@endsection