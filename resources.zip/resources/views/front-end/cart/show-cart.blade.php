
@extends('front-end.master')

@section('title')

    Cart || Youth Fashion

@endsection

@section('body')

    <div class="breadcrumbs">
        <div class="container">
            <ol class="breadcrumb breadcrumb1 animated wow slideInLeft animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: slideInLeft;">
                <li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
                <li class="active">Checkout</li>
            </ol>
        </div>
    </div>
    <!---->
    <div class="container">
        <div class="check-out">
            <h2>Cart</h2>
            <table >
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Prices</th>
                    <th>Delivery details</th>
                    <th>Sub total</th>
                </tr>
                @php($sum=0)
                @foreach($cartProducts as $cartProduct)
                <tr>
                    <td class="ring-in"><a href="single.html" class="at-in"><img src="{{asset($cartProduct->options->image)}}" class="img-responsive" alt=""></a>
                        <div class="sed">
                            <h5>{{$cartProduct->name}}</h5>

                        </div>
                        <div class="clearfix"> </div></td>
                    <td class="check"><input type="text" value="{{$cartProduct->qty}}" ></td>
                    <td>{{$cartProduct->price}}</td>
                    <td>FREE SHIPPING</td>
                    <td>Tk.{{$total = $cartProduct->qty*$cartProduct->price}}</td>
                    <td>
                        <a href="{{route('delete-cart-item',['id' => $cartProduct->rowId])}}" class="btn btn-danger">
                            <i class="">Delete</i>
                        </a>
                    </td>
                </tr>
                   @php($sum=$sum+$total)

                    @endforeach

            </table>
            <div class="col-md-4">
                <div class="row">
                    <table class="table" style="margin-left: 700px">
                        <tr>
                            <th>Item Table</th>
                            <td>{{$sum}}</td>
                        </tr>
                        <tr>
                            <th>Delivery charge</th>
                            <td>{{$del =50}}</td>
                        </tr><tr>
                            <th>Grand Total</th>
                            <td>{{$sum + $del}}</td>
                        </tr>

                    </table>

                </div>
            </div>


            <a href="{{route('/')}}" class=" to-buy" style="margin-right:  700px">Continue Shopping</a>
            <a href="#" class=" to-buy">PROCEED TO BUY</a>
            <div class="clearfix"> </div>
        </div>
    </div>
    <!--footer-->
    <div class="footer">
        <div class="container">
            <div class="footer-top">
                <div class="col-md-6 top-footer">
                    <h3>Follow Us On</h3>
                    <div class="social-icons">
                        <ul class="social">
                            <li><a href="#"><i></i></a> </li>
                            <li><a href="#"><i class="facebook"></i></a></li>
                            <li><a href="#"><i class="google"></i> </a></li>
                            <li><a href="#"><i class="linked"></i> </a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="col-md-6 top-footer1">
                    <h3>Newsletter</h3>
                    <form action="#" method="post">
                        <input type="text" name="email" value="" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='';}">
                        <input type="submit" value="SUBSCRIBE">
                    </form>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="col-md-3 footer-bottom-cate">
                    <h6>Categories</h6>
                    <ul>
                        <li><a href="products.html">Curabitur sapien</a></li>
                        <li><a href="single.html">Dignissim purus</a></li>
                        <li><a href="men.html">Tempus pretium</a></li>
                        <li><a href="products.html">Dignissim neque</a></li>
                        <li><a href="single.html">Ornared id aliquet</a></li>

                    </ul>
                </div>
                <div class="col-md-3 footer-bottom-cate">
                    <h6>Feature Projects</h6>
                    <ul>
                        <li><a href="products.html">Dignissim purus</a></li>
                        <li><a href="men.html">Curabitur sapien</a></li>
                        <li><a href="single.html">Tempus pretium</a></li>
                        <li><a href="men.html">Dignissim neque</a></li>
                        <li><a href="products.html">Ornared id aliquet</a></li>
                    </ul>
                </div>
                <div class="col-md-3 footer-bottom-cate">
                    <h6>Top Brands</h6>
                    <ul>
                        <li><a href="products.html">Tempus pretium</a></li>
                        <li><a href="single.html">Curabitur sapien</a></li>
                        <li><a href="men.html">Dignissim purus</a></li>
                        <li><a href="single.html">Dignissim neque</a></li>
                        <li><a href="men.html">Ornared id aliquet</a></li>


                    </ul>
                </div>
                <div class="col-md-3 footer-bottom-cate cate-bottom">
                    <h6>Our Address</h6>
                    <ul>
                        <li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>Address : 12th Avenue, 5th block, <span>Sydney.</span></li>
                        <li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>Email : <a href="mailto:info@example.com">info@example.com</a></li>
                        <li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>Phone : +1234 567 567</li>
                    </ul>
                </div>
                <div class="clearfix"> </div>
                <p class="footer-class"> © 2016 Youth Fashion . All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
            </div>
        </div>
    </div>


@endsection

